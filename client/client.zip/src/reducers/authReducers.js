import { USER_NAME, USER_EMAIL, USER_PASSWORD, USER_PASSWORD2, TEST_DISPATCH } from '../actions/types';

const initState = {
    isAuthenticated: false,
    user: {
        name: '',
        email: '',
        password: '',
        password2: ''
    }
}

export default function(state = initState, action){
    switch(action.type){
        case USER_NAME: 
          initState.user.name = action.payload
          
          return{
            ...state,
           }

        case USER_EMAIL: 
             initState.user.email = action.payload
             return{
                ...state,
               }

        case USER_PASSWORD: 
              initState.user.password = action.payload
              return{
                ...state,
               }
               
        case USER_PASSWORD2: 
                initState.user.password2 = action.payload
                return{
                    ...state,
                   }
          case TEST_DISPATCH:
              return{
                  ...state,
                  user:  action.payload
              }
        default:
            return state
    }
}