import axios from 'axios';

import { USER_NAME, USER_EMAIL, USER_PASSWORD, USER_PASSWORD2, GET_ERRORS } from './types';

// Resgister User
export const registerUser = userData => dispatch => {
    axios.post('/api/users/signup', userData)
    .then( res => {
        console.log(res)
    }
     )
    .catch(err => 
        { 
            console.log(err.response)
            dispatch({
                type: GET_ERRORS,
                payload: err.response.data
            })
        }
        )
}

export const userName = (userData) => {
    return {
        type: USER_NAME,
        payload: userData
    }
}

export const userEmail = (userData) => {
    return {
        type: USER_EMAIL,
        payload: userData
    }
}

export const userPassword = (userData) => {
    return {
        type: USER_PASSWORD,
        payload: userData
    }
}

export const userPassword2 = (userData) => {
    return {
        type: USER_PASSWORD2,
        payload: userData
    }
}
