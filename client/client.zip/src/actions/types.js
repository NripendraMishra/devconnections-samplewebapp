export const TEST_DISPATCH = 'Test Dispatch'
export const USER_NAME = 'USER_NAME'
export const USER_EMAIL = 'USER_EMAIL'
export const USER_PASSWORD = 'USER_PASSWORD'
export const USER_PASSWORD2 = 'USER_PASSWORD2'


export const GET_ERRORS = 'GET_ERRORS'