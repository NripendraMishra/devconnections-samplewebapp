import React, { Component } from 'react'
import { EmailInput, PasswordInput } from '../layouts/Form';
import { userEmail, userPassword } from '../../actions/authActions';
import { connect } from 'react-redux';
// import store from '../../store';

function LoginForm(props){
    console.log(props)
    return(
        <div className="login">
            <div className="container">
            <div className="row">
                <div className="col-md-8 m-auto">
                <h1 className="display-4 text-center">Login</h1>
                <p className="lead text-center">Signin into your connector account</p>
                <form action="http://localhost:5000">
                        <EmailInput props={props.props}/>  
                        <PasswordInput props={props.props}/>
                <input type="submit" className="btn btn-info btn-block mt-4" />
                </form>
                </div>
            </div>
            </div>
        </div>
    )
}

class Login extends Component {
    render() {
        return (
            <LoginForm props={this.props}/>
        )
    }
}

export default connect(null, {userEmail, userPassword}) (Login) 