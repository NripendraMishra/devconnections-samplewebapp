import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { NameInput, EmailInput, PasswordInput ,Password2Input } from '../layouts/Form';

import { connect } from 'react-redux';
import { registerUser, userName, userEmail, userPassword, userPassword2 } from '../../actions/authActions';

function RegistrationForm(props){

    function onSubmit (e){
        props.props.registerUser(props.props.auth.user, props.props.history)
        e.preventDefault()
    }
   
    return(
        <>
        <div className="register">
            <div className="container">
            <div className="row">
                <div className="col-md-8 m-auto">
                <h1 className="display-4 text-center">Sign Up</h1>
                <p className="lead text-center">Create your DevConnector account</p>
               
               
                <form onSubmit={onSubmit}>
                        <NameInput props={props.props} />
                        <EmailInput props={props.props}/>  
                        <PasswordInput props={props.props}/>
                        <Password2Input props={props.props}/>
                <input type="submit" className="btn btn-info btn-block mt-4" />
                
                </form>
                </div>
            </div>
            </div>
        </div>
        
        </>
    )
}

class Register extends Component {

    constructor() {
        super()
        this.state = {
            errors : {}
        }
    }

    componentWillReceiveProps(nextProps){
        if (nextProps.errors) {
            this.setState({ errors: nextProps.errors });
          }
    }

    render() {
        return (
            <div>
                <RegistrationForm props={this.props} />
            </div>
        )
    }
}

Register.protoTypes = {
    registerUser: PropTypes.func.isRequired,
    auth: PropTypes.object.isRequired,
    errors: PropTypes.object.isRequired
}

const mapStateToProps = (state)=> ({
    auth: state.auth,
    errors: state.errors
})

export default connect(mapStateToProps, {registerUser, userName, userEmail, userPassword, userPassword2}) (Register)
// export default Register