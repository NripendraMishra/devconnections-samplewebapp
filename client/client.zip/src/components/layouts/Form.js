import React, { Component } from 'react'
import classnames from 'classnames';
// import { userName, userEmail, userPassword, userPassword2 } from '../../actions/authActions';


export class NameInput extends Component{
    constructor(){
        super()
         this.state = {
             name: '',
             errors: {}
         }

         this.onChange = this.onChange.bind(this)
    }

    onChange(e){
        e.preventDefault()
        this.setState({
            name: e.target.value
        }, () => {this.props.props.userName(this.state.name)})
    }

    render(){
        return (
            <>
            <div className="form-group">
                 <input type="text" placeholder="Name"  onChange={this.onChange} 
                 className="form-control form-control-lg"  required />
                <label>{this.props.props.errors.user ? this.props.props.errors.user.name : ''}</label>
             </div>
             </>
        )
    }
}

export class EmailInput extends Component{
    constructor(props){
        super(props)
         this.state = {
             email: ''
         }

         this.onChange = this.onChange.bind(this)
    }

    onChange(e){
        e.preventDefault()
        this.setState({
            email: e.target.value
        }, () => {this.props.props.userEmail(this.state.email)})
    }

    render(){
        
        return (
            <div className="form-group">
                <input type="email" placeholder="Email Address" 
                className="form-control form-control-lg" 
                name="email"
                onChange={this.onChange}
                required/>
                <small className="form-text text-muted">This site uses Gravatar so if you want a profile image, use a Gravatar email</small>
            </div>
        )
    }
}

export class PasswordInput extends Component{
    constructor(props){
        super(props)
         this.state = {
             password: ''
         }

         this.onChange = this.onChange.bind(this)
    }

    onChange(e){
        e.preventDefault()
        this.setState({
            password: e.target.value
        }, () => {this.props.props.userPassword(this.state.password)})
    }

    render(){
        return (
            <div className="form-group">
          <input type="password" placeholder="Password"  onChange={this.onChange} className="form-control form-control-lg"  name="password" required/>
        </div>
        )
    }
}


export class Password2Input extends Component{
    constructor(props){
        super(props)
         this.state = {
            password2: ''
         }

         this.onChange = this.onChange.bind(this)
    }

    onChange(e){
        e.preventDefault()
        this.setState({
            password2: e.target.value
        }, () => {this.props.props.userPassword2(this.state.password2)})
    }

    render(){
        return (
            <div className="form-group">
                <input type="password" placeholder="Confirm Password" onChange={this.onChange} className="form-control form-control-lg"  name="password2" required/>
            </div>
        )
    }
}

